﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace VacantEye
{
    public partial class Form1 : Form
    {
        private Panel homePanel;

        public Form1()
        {
            InitializeComponent();
            BuildInterface();
        }

        private void BuildInterface()
        {
            Text = "VacantEye - Campus Parking";
            ClientSize = new Size(1400, 850);
            BackColor = Color.FromArgb(245, 247, 250);

            // Navigation bar
            Panel navBar = new Panel();
            navBar.Location = new Point(0, 0);
            navBar.Size = new Size(1400, 75);
            navBar.BackColor = Color.FromArgb(20, 45, 78);
            Controls.Add(navBar);

            Label logo = new Label();
            logo.Text = "VacantEye";
            logo.Font = new Font("Arial", 24, FontStyle.Bold);
            logo.ForeColor = Color.White;
            logo.AutoSize = false;
            logo.Size = new Size(220, 45);
            logo.Location = new Point(30, 15);
            logo.TextAlign = ContentAlignment.MiddleLeft;
            navBar.Controls.Add(logo);

            Button homeButton = MakeButton("Home", 650);
            Button findButton = MakeButton("Find Parking", 785);
            Button lotsButton = MakeButton("Parking Lots", 920);

            navBar.Controls.Add(homeButton);
            navBar.Controls.Add(findButton);
            navBar.Controls.Add(lotsButton);

            homeButton.Click += HomeButton_Click;
            findButton.Click += FindButton_Click;
            lotsButton.Click += LotsButton_Click;

            // Home page
            BuildHomePage();
        }

        private void BuildHomePage()
        {
            homePanel = new Panel();
            homePanel.Location = new Point(0, 75);
            homePanel.Size = new Size(1400, 775);
            homePanel.BackColor = Color.FromArgb(245, 247, 250);
            Controls.Add(homePanel);

            Label welcome = new Label();
            welcome.Text = "Welcome to VacantEye";
            welcome.Font = new Font("Arial", 21, FontStyle.Bold);
            welcome.ForeColor = Color.FromArgb(25, 40, 60);
            welcome.AutoSize = false;
            welcome.Size = new Size(525, 42);
            welcome.Location = new Point(40, 8);
            welcome.TextAlign = ContentAlignment.MiddleLeft;
            homePanel.Controls.Add(welcome);

            Label subtitle = new Label();
            subtitle.Text = "A smarter way to find parking at WVU Tech";
            subtitle.Font = new Font("Arial", 14);
            subtitle.ForeColor = Color.FromArgb(80, 90, 100);
            subtitle.AutoSize = false;
            subtitle.Size = new Size(700, 35);
            subtitle.Location = new Point(53, 65);
            subtitle.TextAlign = ContentAlignment.MiddleLeft;
            homePanel.Controls.Add(subtitle);

            // WVU Tech section
            Panel wvuPanel = new Panel();
            wvuPanel.Location = new Point(50, 120);
            wvuPanel.Size = new Size(350, 500);
            wvuPanel.BackColor = Color.White;
            wvuPanel.BorderStyle = BorderStyle.FixedSingle;
            homePanel.Controls.Add(wvuPanel);

            Label wvuTitle = new Label();
            wvuTitle.Text = "WVU Tech";
            wvuTitle.Font = new Font("Arial", 23, FontStyle.Bold);
            wvuTitle.ForeColor = Color.FromArgb(25, 40, 60);
            wvuTitle.AutoSize = false;
            wvuTitle.Size = new Size(300, 45);
            wvuTitle.Location = new Point(25, 25);
            wvuTitle.TextAlign = ContentAlignment.MiddleLeft;
            wvuPanel.Controls.Add(wvuTitle);

            Label wvuLine = new Label();
            wvuLine.Text = "West Virginia University Institute of Technology";
            wvuLine.Font = new Font("Arial", 12, FontStyle.Bold);
            wvuLine.ForeColor = Color.FromArgb(70, 80, 90);
            wvuLine.AutoSize = false;
            wvuLine.Size = new Size(295, 55);
            wvuLine.Location = new Point(25, 75);
            wvuLine.TextAlign = ContentAlignment.MiddleLeft;
            wvuPanel.Controls.Add(wvuLine);

            Label wvuInfo = new Label();
            wvuInfo.Text =
                "VacantEye is designed for the WVU Tech campus " +
                "to help students find available parking more easily.\n\n" +
                "The system is designed around the campus " +
                "parking areas and classroom buildings.\n\n" +
                "Students will be able to use the system to " +
                "check parking availability before arriving at " +
                "class.";
            wvuInfo.Font = new Font("Arial", 11);
            wvuInfo.ForeColor = Color.FromArgb(80, 90, 100);
            wvuInfo.AutoSize = false;
            wvuInfo.Size = new Size(295, 270);
            wvuInfo.Location = new Point(25, 145);
            wvuInfo.TextAlign = ContentAlignment.TopLeft;
            wvuPanel.Controls.Add(wvuInfo);

            Label wvuBottom = new Label();
            wvuBottom.Text = "Campus Parking Solution";
            wvuBottom.Font = new Font("Arial", 12, FontStyle.Bold);
            wvuBottom.ForeColor = Color.FromArgb(35, 65, 105);
            wvuBottom.AutoSize = false;
            wvuBottom.Size = new Size(295, 35);
            wvuBottom.Location = new Point(25, 420);
            wvuBottom.TextAlign = ContentAlignment.MiddleLeft;
            wvuPanel.Controls.Add(wvuBottom);

            // Our goal section
            Panel goalPanel = new Panel();
            goalPanel.Location = new Point(425, 120);
            goalPanel.Size = new Size(550, 500);
            goalPanel.BackColor = Color.White;
            goalPanel.BorderStyle = BorderStyle.FixedSingle;
            homePanel.Controls.Add(goalPanel);

            Label goalTitle = new Label();
            goalTitle.Text = "Our Goal";
            goalTitle.Font = new Font("Arial", 26, FontStyle.Bold);
            goalTitle.ForeColor = Color.FromArgb(25, 40, 60);
            goalTitle.AutoSize = false;
            goalTitle.Size = new Size(490, 50);
            goalTitle.Location = new Point(30, 25);
            goalTitle.TextAlign = ContentAlignment.MiddleLeft;
            goalPanel.Controls.Add(goalTitle);

            Label goalSubtitle = new Label();
            goalSubtitle.Text = "Making campus parking easier for students";
            goalSubtitle.Font = new Font("Arial", 13, FontStyle.Bold);
            goalSubtitle.ForeColor = Color.FromArgb(35, 65, 105);
            goalSubtitle.AutoSize = false;
            goalSubtitle.Size = new Size(490, 35);
            goalSubtitle.Location = new Point(30, 75);
            goalSubtitle.TextAlign = ContentAlignment.MiddleLeft;
            goalPanel.Controls.Add(goalSubtitle);

            Label goalText = new Label();
            goalText.Text =
                "Our goal with VacantEye is to give WVU Tech a " +
                "solution to the parking problem on campus.\n\n" +
                "We want to create an interactive, live parking " +
                "map that allows students to see available " +
                "parking spots instead of mindlessly driving " +
                "around campus looking for somewhere to park.\n\n" +
                "We are a team of five seniors working on this " +
                "project as part of our capstone class. Our goal " +
                "is to create an affordable and convenient way " +
                "for students to find parking around campus.\n\n" +
                "VacantEye is designed to make finding a parking " +
                "spot easier, faster, and less frustrating for " +
                "students.";
            goalText.Font = new Font("Arial", 12);
            goalText.ForeColor = Color.FromArgb(65, 75, 85);
            goalText.AutoSize = false;
            goalText.Size = new Size(490, 320);
            goalText.Location = new Point(30, 120);
            goalText.TextAlign = ContentAlignment.TopLeft;
            goalPanel.Controls.Add(goalText);

            Label teamLabel = new Label();
            teamLabel.Text = "5 Seniors • Capstone Project";
            teamLabel.Font = new Font("Arial", 12, FontStyle.Bold);
            teamLabel.ForeColor = Color.FromArgb(30, 140, 80);
            teamLabel.AutoSize = false;
            teamLabel.Size = new Size(490, 30);
            teamLabel.Location = new Point(30, 450);
            teamLabel.TextAlign = ContentAlignment.MiddleLeft;
            goalPanel.Controls.Add(teamLabel);

            // VacantEye section
            Panel bearPanel = new Panel();
            bearPanel.Location = new Point(1000, 120);
            bearPanel.Size = new Size(350, 500);
            bearPanel.BackColor = Color.White;
            bearPanel.BorderStyle = BorderStyle.FixedSingle;
            homePanel.Controls.Add(bearPanel);

            Label bearTitle = new Label();
            bearTitle.Text = "VaycantEye";
            bearTitle.Font = new Font("Arial", 23, FontStyle.Bold);
            bearTitle.ForeColor = Color.FromArgb(25, 40, 60);
            bearTitle.AutoSize = false;
            bearTitle.Size = new Size(300, 45);
            bearTitle.Location = new Point(25, 25);
            bearTitle.TextAlign = ContentAlignment.MiddleCenter;
            bearPanel.Controls.Add(bearTitle);

            Panel logoPlaceholder = new Panel();
            logoPlaceholder.Location = new Point(75, 95);
            logoPlaceholder.Size = new Size(200, 200);
            logoPlaceholder.BackColor = Color.FromArgb(235, 238, 242);
            logoPlaceholder.BorderStyle = BorderStyle.FixedSingle;
            bearPanel.Controls.Add(logoPlaceholder);

            Label logoText = new Label();
            logoText.Text = "Vaycant\nEye\nLogo";
            logoText.Font = new Font("Arial", 20, FontStyle.Bold);
            logoText.ForeColor = Color.FromArgb(80, 90, 100);
            logoText.AutoSize = false;
            logoText.Size = new Size(190, 150);
            logoText.Location = new Point(5, 25);
            logoText.TextAlign = ContentAlignment.MiddleCenter;
            logoPlaceholder.Controls.Add(logoText);

            Label bearInfo = new Label();
            bearInfo.Text =
                "Vaycant Eye\n\n" +
                "VacantEye is being developed " +
                "as a student capstone project " +
                "to help improve the campus " +
                "parking experience.";
            bearInfo.Font = new Font("Arial", 11);
            bearInfo.ForeColor = Color.FromArgb(80, 90, 100);
            bearInfo.AutoSize = false;
            bearInfo.Size = new Size(295, 130);
            bearInfo.Location = new Point(25, 325);
            bearInfo.TextAlign = ContentAlignment.TopCenter;
            bearPanel.Controls.Add(bearInfo);

            // Bottom information
            Label bottomInfo = new Label();
            bottomInfo.Text =
                "Interactive Live Parking Map  •  Multiple Classroom Locations  •  Convenient Parking Search";
            bottomInfo.Font = new Font("Arial", 11, FontStyle.Bold);
            bottomInfo.ForeColor = Color.FromArgb(80, 90, 100);
            bottomInfo.AutoSize = false;
            bottomInfo.Size = new Size(1250, 35);
            bottomInfo.Location = new Point(50, 660);
            bottomInfo.TextAlign = ContentAlignment.MiddleCenter;
            homePanel.Controls.Add(bottomInfo);
        }

        // Navigation button
        private Button MakeButton(string text, int x)
        {
            Button button = new Button();

            button.Text = text;
            button.Location = new Point(x, 15);
            button.Size = new Size(125, 45);
            button.BackColor = Color.FromArgb(35, 65, 105);
            button.ForeColor = Color.White;
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.TextAlign = ContentAlignment.MiddleCenter;
            button.Font = new Font("Arial", 11, FontStyle.Regular);
            button.UseCompatibleTextRendering = true;

            return button;
        }

        // Home button
        private void HomeButton_Click(object sender, EventArgs e)
        {
        }

        // Find parking button
        private void FindButton_Click(object sender, EventArgs e)
        {
            FindParkingForm parkingForm =
                new FindParkingForm();

            parkingForm.ShowDialog(this);
        }

        // Parking lots button
        private void LotsButton_Click(object sender, EventArgs e)
        {
            ParkingLotSelectionForm lotForm =
                new ParkingLotSelectionForm();

            if (lotForm.ShowDialog(this) == DialogResult.OK)
            {
                if (lotForm.SelectedLot == "Main Parking Lot")
                {
                    ParkingMapForm mapForm =
                        new ParkingMapForm();

                    mapForm.ShowDialog(this);
                }
            }
        }
    }

    // Parking lot selection
    public class ParkingLotSelectionForm : Form
    {
        private ComboBox parkingLotBox;

        public string SelectedLot { get; private set; }

        public ParkingLotSelectionForm()
        {
            BuildForm();
        }

        private void BuildForm()
        {
            Text = "VacantEye - Parking Lots";
            Size = new Size(500, 350);
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Color.FromArgb(245, 247, 250);

            Label title = new Label();
            title.Text = "Select a Parking Lot";
            title.Font =
                new Font("Arial", 24, FontStyle.Bold);
            title.ForeColor =
                Color.FromArgb(25, 40, 60);
            title.AutoSize = true;
            title.Location = new Point(35, 30);
            Controls.Add(title);

            Label instructions = new Label();
            instructions.Text =
                "Choose the parking lot you want to view.";
            instructions.Font =
                new Font("Arial", 11);
            instructions.ForeColor =
                Color.FromArgb(80, 90, 100);
            instructions.AutoSize = true;
            instructions.Location = new Point(38, 80);
            Controls.Add(instructions);

            Label lotLabel = new Label();
            lotLabel.Text = "Parking Lot:";
            lotLabel.Font =
                new Font("Arial", 11, FontStyle.Bold);
            lotLabel.AutoSize = true;
            lotLabel.Location = new Point(40, 125);
            Controls.Add(lotLabel);

            parkingLotBox = new ComboBox();
            parkingLotBox.Location = new Point(40, 155);
            parkingLotBox.Size = new Size(400, 35);
            parkingLotBox.DropDownStyle =
                ComboBoxStyle.DropDownList;

            parkingLotBox.Items.Add(
                "Main Parking Lot");

            parkingLotBox.SelectedIndex = 0;

            Controls.Add(parkingLotBox);

            Button openButton = new Button();
            openButton.Text = "View Parking Lot";
            openButton.Location = new Point(40, 215);
            openButton.Size = new Size(180, 45);
            openButton.BackColor =
                Color.FromArgb(35, 65, 105);
            openButton.ForeColor = Color.White;
            openButton.FlatStyle = FlatStyle.Flat;
            openButton.FlatAppearance.BorderSize = 0;
            openButton.Font =
                new Font("Arial", 11, FontStyle.Bold);

            openButton.Click += OpenButton_Click;

            Controls.Add(openButton);

            Button cancelButton = new Button();
            cancelButton.Text = "Cancel";
            cancelButton.Location = new Point(240, 215);
            cancelButton.Size = new Size(120, 45);
            cancelButton.BackColor =
                Color.FromArgb(220, 223, 227);
            cancelButton.ForeColor =
                Color.FromArgb(40, 40, 40);
            cancelButton.FlatStyle = FlatStyle.Flat;
            cancelButton.FlatAppearance.BorderSize = 0;
            cancelButton.Font =
                new Font("Arial", 11);

            cancelButton.Click += (sender, e) =>
            {
                DialogResult = DialogResult.Cancel;
                Close();
            };

            Controls.Add(cancelButton);
        }

        private void OpenButton_Click(object sender, EventArgs e)
        {
            if (parkingLotBox.SelectedItem == null)
                return;

            SelectedLot =
                parkingLotBox.SelectedItem.ToString();

            DialogResult = DialogResult.OK;
            Close();
        }
    }

    // Parking map
    public class ParkingMapForm : Form
    {
        public ParkingMapForm()
        {
            BuildForm();
        }

        private void BuildForm()
        {
            Text = "VacantEye - Main Parking Lot";
            ClientSize = new Size(1350, 700);
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Color.FromArgb(245, 247, 250);

            Label title = new Label();
            title.Text = "Main Campus Parking Lot";
            title.Font =
                new Font("Arial", 23, FontStyle.Bold);
            title.ForeColor =
                Color.FromArgb(25, 40, 60);
            title.AutoSize = false;
            title.Size = new Size(600, 45);
            title.Location = new Point(50, 25);
            title.TextAlign =
                ContentAlignment.MiddleLeft;
            Controls.Add(title);

            Label live = new Label();
            live.Text = "● LIVE PARKING DATA";
            live.Font =
                new Font("Arial", 12, FontStyle.Bold);
            live.ForeColor =
                Color.FromArgb(30, 140, 80);
            live.AutoSize = false;
            live.Size = new Size(250, 30);
            live.Location = new Point(52, 75);
            live.TextAlign =
                ContentAlignment.MiddleLeft;
            Controls.Add(live);

            ParkingMap map = new ParkingMap();
            map.Location = new Point(50, 115);
            map.Size = new Size(1250, 500);
            Controls.Add(map);

            Label availableLabel = new Label();
            availableLabel.Text = "■  Available";
            availableLabel.Font =
                new Font("Arial", 11, FontStyle.Bold);
            availableLabel.ForeColor =
                Color.FromArgb(45, 155, 90);
            availableLabel.AutoSize = true;
            availableLabel.Location =
                new Point(55, 635);
            Controls.Add(availableLabel);

            Label occupiedLabel = new Label();
            occupiedLabel.Text = "■  Occupied";
            occupiedLabel.Font =
                new Font("Arial", 11, FontStyle.Bold);
            occupiedLabel.ForeColor =
                Color.FromArgb(190, 65, 65);
            occupiedLabel.AutoSize = true;
            occupiedLabel.Location =
                new Point(175, 635);
            Controls.Add(occupiedLabel);
        }
    }

    // Find parking
    public class FindParkingForm : Form
    {
        private ComboBox buildingBox;
        private DateTimePicker startTime;
        private DateTimePicker endTime;
        private ListBox classList;

        private List<ClassInfo> classes =
            new List<ClassInfo>();

        public FindParkingForm()
        {
            BuildForm();
        }

        private void BuildForm()
        {
            Text = "VacantEye - Find Parking";
            Size = new Size(650, 600);
            StartPosition =
                FormStartPosition.CenterParent;
            BackColor =
                Color.FromArgb(245, 247, 250);

            Label title = new Label();
            title.Text = "Find Parking";
            title.Font =
                new Font("Arial", 24, FontStyle.Bold);
            title.ForeColor =
                Color.FromArgb(25, 40, 60);
            title.AutoSize = true;
            title.Location =
                new Point(35, 25);
            Controls.Add(title);

            Label instructions = new Label();
            instructions.Text =
                "Enter the buildings and class times you need parking for.";
            instructions.Font =
                new Font("Arial", 11);
            instructions.ForeColor =
                Color.FromArgb(80, 90, 100);
            instructions.AutoSize = true;
            instructions.Location =
                new Point(38, 70);
            Controls.Add(instructions);

            Label buildingLabel = new Label();
            buildingLabel.Text =
                "Which building is your classroom in?";
            buildingLabel.Font =
                new Font("Arial", 11, FontStyle.Bold);
            buildingLabel.AutoSize = true;
            buildingLabel.Location =
                new Point(40, 115);
            Controls.Add(buildingLabel);

            buildingBox = new ComboBox();
            buildingBox.Location =
                new Point(40, 145);
            buildingBox.Size =
                new Size(250, 35);
            buildingBox.DropDownStyle =
                ComboBoxStyle.DropDownList;

            buildingBox.Items.AddRange(
                new object[]
                {
                    "Classroom Building (CLB)",
                    "Innovation Building (INN)",
                    "Physical Sciences Building (LAB)",
                    "Engineering Laboratory Building (ELB)",
                    "Life Sciences Building (LIF)",
                    "Carter Hall (CAR)",
                    "Robert C. Byrd Learning Resources Center (RCC)"
                });

            Controls.Add(buildingBox);

            Label startLabel = new Label();
            startLabel.Text = "Class starts:";
            startLabel.Font =
                new Font("Arial", 11, FontStyle.Bold);
            startLabel.AutoSize = true;
            startLabel.Location =
                new Point(330, 115);
            Controls.Add(startLabel);

            startTime = new DateTimePicker();
            startTime.Format =
                DateTimePickerFormat.Time;
            startTime.ShowUpDown = true;
            startTime.Location =
                new Point(330, 145);
            startTime.Size =
                new Size(120, 35);
            startTime.Value =
                DateTime.Today.AddHours(8);
            Controls.Add(startTime);

            Label endLabel = new Label();
            endLabel.Text = "Class ends:";
            endLabel.Font =
                new Font("Arial", 11, FontStyle.Bold);
            endLabel.AutoSize = true;
            endLabel.Location =
                new Point(470, 115);
            Controls.Add(endLabel);

            endTime = new DateTimePicker();
            endTime.Format =
                DateTimePickerFormat.Time;
            endTime.ShowUpDown = true;
            endTime.Location =
                new Point(470, 145);
            endTime.Size =
                new Size(120, 35);
            endTime.Value =
                DateTime.Today.AddHours(9);
            Controls.Add(endTime);

            Button addClass = new Button();
            addClass.Text = "+ Add Class";
            addClass.Location =
                new Point(40, 195);
            addClass.Size =
                new Size(150, 40);
            addClass.BackColor =
                Color.FromArgb(35, 65, 105);
            addClass.ForeColor = Color.White;
            addClass.FlatStyle =
                FlatStyle.Flat;
            addClass.FlatAppearance.BorderSize = 0;
            addClass.Font =
                new Font("Arial", 11, FontStyle.Bold);
            addClass.Click +=
                AddClass_Click;
            Controls.Add(addClass);

            Label addedLabel = new Label();
            addedLabel.Text = "Your Classes";
            addedLabel.Font =
                new Font("Arial", 13, FontStyle.Bold);
            addedLabel.ForeColor =
                Color.FromArgb(25, 40, 60);
            addedLabel.AutoSize = true;
            addedLabel.Location =
                new Point(40, 255);
            Controls.Add(addedLabel);

            classList = new ListBox();
            classList.Location =
                new Point(40, 290);
            classList.Size =
                new Size(550, 150);
            classList.Font =
                new Font("Arial", 10);
            Controls.Add(classList);

            Button removeClass = new Button();
            removeClass.Text =
                "Remove Selected";
            removeClass.Location =
                new Point(40, 455);
            removeClass.Size =
                new Size(160, 40);
            removeClass.BackColor =
                Color.FromArgb(220, 80, 80);
            removeClass.ForeColor =
                Color.White;
            removeClass.FlatStyle =
                FlatStyle.Flat;
            removeClass.FlatAppearance.BorderSize = 0;
            removeClass.Font =
                new Font("Arial", 10, FontStyle.Bold);
            removeClass.Click +=
                RemoveClass_Click;
            Controls.Add(removeClass);

            Button findParking = new Button();
            findParking.Text =
                "Find Available Parking";
            findParking.Location =
                new Point(360, 455);
            findParking.Size =
                new Size(230, 40);
            findParking.BackColor =
                Color.FromArgb(35, 65, 105);
            findParking.ForeColor =
                Color.White;
            findParking.FlatStyle =
                FlatStyle.Flat;
            findParking.FlatAppearance.BorderSize = 0;
            findParking.Font =
                new Font("Arial", 10, FontStyle.Bold);
            findParking.Click +=
                FindParking_Click;
            Controls.Add(findParking);
        }

        private void AddClass_Click(
            object sender,
            EventArgs e)
        {
            if (buildingBox.SelectedItem == null)
            {
                MessageBox.Show(
                    "Please select the building your class is in.",
                    "Missing Building",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            string building =
                buildingBox.SelectedItem.ToString();

            TimeSpan start =
                startTime.Value.TimeOfDay;

            TimeSpan end =
                endTime.Value.TimeOfDay;

            if (end <= start)
            {
                MessageBox.Show(
                    "The class end time must be after the start time.",
                    "Invalid Time",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            classes.Add(
                new ClassInfo(
                    building,
                    start,
                    end));

            UpdateClassList();

            buildingBox.SelectedIndex = -1;
        }

        private void UpdateClassList()
        {
            classList.Items.Clear();

            foreach (ClassInfo classInfo in classes)
            {
                string classText =
                    classInfo.Building +
                    "     " +
                    classInfo.Start.ToString(@"h\:mm") +
                    " - " +
                    classInfo.End.ToString(@"h\:mm");

                classList.Items.Add(classText);
            }
        }

        private void RemoveClass_Click(
            object sender,
            EventArgs e)
        {
            if (classList.SelectedIndex == -1)
            {
                MessageBox.Show(
                    "Please select a class to remove.",
                    "No Class Selected",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                return;
            }

            int index =
                classList.SelectedIndex;

            classes.RemoveAt(index);

            UpdateClassList();
        }

        private void FindParking_Click(
            object sender,
            EventArgs e)
        {
            if (classes.Count == 0)
            {
                MessageBox.Show(
                    "Please add at least one class first.",
                    "No Classes Added",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                return;
            }

            MessageBox.Show(
                "Your class information has been saved.\n\n" +
                "VacantEye will eventually use your classroom " +
                "buildings and class times to determine the " +
                "best available parking.",
                "Parking Search",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }
    }

    // Class information
    public class ClassInfo
    {
        public string Building { get; set; }
        public TimeSpan Start { get; set; }
        public TimeSpan End { get; set; }

        public ClassInfo(
            string building,
            TimeSpan start,
            TimeSpan end)
        {
            Building = building;
            Start = start;
            End = end;
        }
    }

    // Parking map
    public class ParkingMap : Panel
    {
        private bool[] occupied =
            new bool[30];

        public ParkingMap()
        {
            DoubleBuffered = true;

            BackColor =
                Color.FromArgb(60, 63, 68);

            // Parking spaces
            for (int i = 0; i < 30; i++)
            {
                occupied[i] = i % 4 == 0;
            }
        }

        protected override void OnPaint(
            PaintEventArgs e)
        {
            base.OnPaint(e);

            Graphics g = e.Graphics;

            g.SmoothingMode =
                SmoothingMode.AntiAlias;

            DrawLot(g);
        }

        private void DrawLot(Graphics g)
        {
            Rectangle lot =
                new Rectangle(
                    10,
                    10,
                    Width - 20,
                    Height - 20);

            using (SolidBrush pavementBrush =
                new SolidBrush(
                    Color.FromArgb(60, 63, 68)))
            {
                g.FillRectangle(
                    pavementBrush,
                    lot);
            }

            using (Pen borderPen =
                new Pen(Color.White, 3))
            {
                g.DrawRectangle(
                    borderPen,
                    lot);
            }

            // Driving lane
            int laneY =
                Height / 2 - 45;

            using (SolidBrush laneBrush =
                new SolidBrush(
                    Color.FromArgb(72, 75, 80)))
            {
                g.FillRectangle(
                    laneBrush,
                    15,
                    laneY,
                    Width - 30,
                    90);
            }

            // Yellow line
            using (Pen yellowPen =
                new Pen(Color.Gold, 3))
            {
                yellowPen.DashStyle =
                    DashStyle.Dash;

                g.DrawLine(
                    yellowPen,
                    20,
                    Height / 2,
                    Width - 20,
                    Height / 2);
            }

            int spotWidth = 75;
            int spotHeight = 150;
            int startX = 35;
            int spacing = 78;

            // Top parking row
            for (int i = 0; i < 15; i++)
            {
                int x =
                    startX + (i * spacing);

                int y = 25;

                DrawSpot(
                    g,
                    x,
                    y,
                    spotWidth,
                    spotHeight,
                    occupied[i],
                    "P" + (i + 1),
                    true);
            }

            // Bottom parking row
            for (int i = 0; i < 15; i++)
            {
                int x =
                    startX + (i * spacing);

                int y =
                    Height - 180;

                DrawSpot(
                    g,
                    x,
                    y,
                    spotWidth,
                    spotHeight,
                    occupied[i + 15],
                    "P" + (i + 16),
                    false);
            }
        }

        private void DrawSpot(
            Graphics g,
            int x,
            int y,
            int width,
            int height,
            bool isOccupied,
            string label,
            bool top)
        {
            Point[] points;

            if (top)
            {
                points = new Point[]
                {
                    new Point(
                        x + 5,
                        y + height),

                    new Point(
                        x + 25,
                        y),

                    new Point(
                        x + width,
                        y),

                    new Point(
                        x + width - 20,
                        y + height)
                };
            }
            else
            {
                points = new Point[]
                {
                    new Point(
                        x + 20,
                        y),

                    new Point(
                        x + width,
                        y),

                    new Point(
                        x + width - 20,
                        y + height),

                    new Point(
                        x,
                        y + height)
                };
            }

            Color spotColor;

            if (isOccupied)
            {
                spotColor =
                    Color.FromArgb(190, 65, 65);
            }
            else
            {
                spotColor =
                    Color.FromArgb(45, 155, 90);
            }

            using (SolidBrush brush =
                new SolidBrush(spotColor))
            {
                g.FillPolygon(
                    brush,
                    points);
            }

            using (Pen outline =
                new Pen(Color.White, 2))
            {
                g.DrawPolygon(
                    outline,
                    points);
            }

            using (Font font =
                new Font(
                    "Arial",
                    9,
                    FontStyle.Bold))
            using (SolidBrush textBrush =
                new SolidBrush(Color.White))
            {
                RectangleF textArea =
                    new RectangleF(
                        x,
                        y + (height / 2) - 10,
                        width,
                        20);

                StringFormat format =
                    new StringFormat();

                format.Alignment =
                    StringAlignment.Center;

                format.LineAlignment =
                    StringAlignment.Center;

                g.DrawString(
                    label,
                    font,
                    textBrush,
                    textArea,
                    format);
            }
        }
    }
}
